package com.example.aimoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lines: LinesView
    private val all = mutableListOf<View>()
    private val handles = mutableListOf<View>()
    private var shown = true

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(
            1,
            Notification.Builder(this, "ov")
                .setContentTitle("خطوط التصويب تعمل")
                .setSmallIcon(android.R.drawable.ic_menu_edit)
                .build()
        )

        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // نافذة الرسم: لا تستقبل أي لمسة، فتمر كلها إلى اللعبة
        lines = LinesView(this)
        val lp = WindowManager.LayoutParams(
            -1, -1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        applyCutout(lp)
        wm.addView(lines, lp)
        all.add(lines)

        addHandle(State.cue, Color.WHITE, "C")
        addHandle(State.aim, Color.YELLOW, "A")
        addHandle(State.tl, Color.CYAN, "◤")
        addHandle(State.br, Color.CYAN, "◢")
        addHandle(State.tgt, Color.rgb(255, 140, 0), "T")
        addPanel()
    }

    private fun applyCutout(lp: WindowManager.LayoutParams) {
        // أندرويد 12 يحجب اللمسات التي تعبر نافذة عائمة شفافيتها أكثر من 0.8
        lp.alpha = 0.75f
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun addHandle(pt: PointF, color: Int, label: String) {
        val size = dp(40)
        val v = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(130, Color.red(color), Color.green(color), Color.blue(color)))
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (pt.x - size / 2).toInt()
            y = (pt.y - size / 2).toInt()
        }
        applyCutout(lp)
        val loc = IntArray(2)
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            v.getLocationOnScreen(loc)
            pt.x = loc[0] + size / 2f
            pt.y = loc[1] + size / 2f
            lines.invalidate()
        }
        var offX = 0f
        var offY = 0f
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    offX = e.rawX - lp.x
                    offY = e.rawY - lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (e.rawX - offX).toInt()
                    lp.y = (e.rawY - offY).toInt()
                    wm.updateViewLayout(v, lp)
                }
            }
            true
        }
        wm.addView(v, lp)
        all.add(v)
        handles.add(v)
    }

    private fun addPanel() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(120, 0, 0, 0))
        }
        fun btn(t: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.minWidth = 0
            b.minimumWidth = 0
            b.layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
            b.setOnClickListener { onClick() }
            panel.addView(b)
        }
        btn("👁") {
            shown = !shown
            val vis = if (shown) View.VISIBLE else View.INVISIBLE
            lines.visibility = vis
            handles.forEach { it.visibility = vis }
        }
        btn("◎") { State.showPockets = !State.showPockets; lines.invalidate() }
        btn("L+") { State.cueLen = min(3000f, State.cueLen + 150f); lines.invalidate() }
        btn("L-") { State.cueLen = max(100f, State.cueLen - 150f); lines.invalidate() }
        btn("＋") { State.alpha = min(255, State.alpha + 25); lines.invalidate() }
        btn("－") { State.alpha = max(30, State.alpha - 25); lines.invalidate() }
        btn("✕") { stopSelf() }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dp(30)
        }
        applyCutout(lp)
        wm.addView(panel, lp)
        all.add(panel)
    }

    override fun onDestroy() {
        all.forEach { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }
}
