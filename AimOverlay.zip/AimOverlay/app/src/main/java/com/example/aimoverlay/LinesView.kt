package com.example.aimoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PointF
import android.view.View
import kotlin.math.hypot

object State {
    var cue = PointF(400f, 1300f)   // الكرة البيضاء
    var aim = PointF(700f, 600f)    // قرب هذا المقبض من الجيب الذي تريده
    var tgt = PointF(900f, 800f)    // الكرة الهدف = نقطة الوسط التي تلتقي عندها كل الخطوط
    var tl = PointF(120f, 250f)     // أعلى اليسار للطاولة
    var br = PointF(960f, 1900f)    // أسفل اليمين للطاولة
    var showPockets = true          // خطوط بقية الجيوب
    var alpha = 230
    var cueLen = 600f               // طول خط انحراف البيضاء بعد التماس
}

class LinesView(ctx: Context) : View(ctx) {
    private val solid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f)
    }
    private val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
    }
    private val circle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2f
        style = Paint.Style.STROKE
        color = Color.argb(90, 255, 255, 0)
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val loc = IntArray(2)

    private fun col(a: Int, r: Int, g: Int, b: Int) =
        Color.argb(a.coerceIn(0, 255), r, g, b)

    // الجيوب الستة (منزاحة قليلاً للخارج)
    private fun pockets(r: Float): List<PointF> = with(State) {
        val mx = (tl.x + br.x) / 2f
        listOf(
            PointF(tl.x - r, tl.y - r), PointF(br.x + r, tl.y - r),
            PointF(tl.x - r, br.y + r), PointF(br.x + r, br.y + r),
            PointF(mx, tl.y - r * 1.5f), PointF(mx, br.y + r * 1.5f)
        )
    }

    override fun onDraw(c: Canvas) {
        // إحداثيات الشاشة الفعلية (يعالج إزاحة النوتش)
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())

        val s = State
        c.drawRect(s.tl.x, s.tl.y, s.br.x, s.br.y, box)

        val r = 0.0153f * (s.br.x - s.tl.x)   // نصف قطر الكرة تقريباً
        val t = s.tgt
        val ps = pockets(r)

        // الجيب المختار = الأقرب إلى المقبض A
        var sel = 0
        var best = Float.MAX_VALUE
        ps.forEachIndexed { i, p ->
            val d = hypot(p.x - s.aim.x, p.y - s.aim.y)
            if (d < best) { best = d; sel = i }
        }

        // بقية الجيوب: خطوط خافتة من نقطة الوسط
        if (s.showPockets) {
            thin.color = col(s.alpha * 8 / 10, 255, 220, 0)
            thin.strokeWidth = 3.5f
            ps.forEachIndexed { i, p ->
                if (i != sel) c.drawLine(t.x, t.y, p.x, p.y, thin)
            }
        }

        val p = ps[sel]
        val dx = p.x - t.x
        val dy = p.y - t.y
        val dist = hypot(dx, dy)
        if (dist > 1f) {
            val ux = dx / dist
            val uy = dy / dist
            val gx = t.x - ux * 2 * r     // موضع البيضاء عند التماس
            val gy = t.y - uy * 2 * r

            // الهدف ← الجيب
            solid.color = col(s.alpha, 255, 220, 0)
            c.drawLine(t.x, t.y, p.x, p.y, solid)
            // البيضاء ← موضع التماس
            solid.color = col(s.alpha, 255, 255, 255)
            c.drawLine(s.cue.x, s.cue.y, gx, gy, solid)
            // موضع التماس ← الهدف
            dash.color = col(s.alpha * 2 / 3, 255, 255, 255)
            c.drawLine(gx, gy, t.x, t.y, dash)
            circle.color = col(s.alpha, 255, 255, 255)
            c.drawCircle(gx, gy, r, circle)

            // خط انحراف البيضاء بعد التماس: عمودي على خط الهدف، ويتجه مع اتجاه حركتها
            val ix = gx - s.cue.x
            val iy = gy - s.cue.y
            var px = -uy
            var py = ux
            if (px * ix + py * iy < 0f) { px = -px; py = -py }
            solid.color = col(s.alpha, 120, 255, 120)
            c.drawLine(gx, gy, gx + px * s.cueLen, gy + py * s.cueLen, solid)
        }

        // نقطة الوسط
        dot.color = col(s.alpha, 255, 140, 0)
        c.drawCircle(t.x, t.y, 7f, dot)
    }
}
