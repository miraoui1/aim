package com.example.aimoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PointF
import android.view.View
import kotlin.math.hypot

object State {
    var cue = PointF(400f, 1300f)   // الكرة البيضاء
    var aim = PointF(700f, 600f)    // قرب هذا المقبض من الجيب الذي تريده
    var tgt = PointF(900f, 800f)    // الكرة الهدف = نقطة الوسط التي تلتقي عندها كل الخطوط
    var tl = PointF(120f, 250f)     // أعلى اليسار للطاولة
    var br = PointF(960f, 1900f)    // أسفل اليمين للطاولة
    var showPockets = true          // خطوط بقية الجيوب
    var bankMode = 0                // 0 بدون ارتداد، 1 ارتداد الجيب المختار، 2 ارتداد كل الجيوب
    var alpha = 230
}

class LinesView(ctx: Context) : View(ctx) {
    private val solid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f)
    }
    private val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
    }
    private val circle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2f
        style = Paint.Style.STROKE
        color = Color.argb(90, 255, 255, 0)
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val loc = IntArray(2)

    private fun col(a: Int, r: Int, g: Int, b: Int) =
        Color.argb(a.coerceIn(0, 255), r, g, b)

    // الجيوب الستة (منزاحة قليلاً للخارج)
    private fun pockets(r: Float): List<PointF> = with(State) {
        val mx = (tl.x + br.x) / 2f
        listOf(
            PointF(tl.x - r, tl.y - r), PointF(br.x + r, tl.y - r),
            PointF(tl.x - r, br.y + r), PointF(br.x + r, br.y + r),
            PointF(mx, tl.y - r * 1.5f), PointF(mx, br.y + r * 1.5f)
        )
    }

    // مسارات الارتداد من الهدف إلى الجيب عبر كل جانب (طريقة المرآة)
    private fun banks(c: Canvas, t: PointF, p: PointF, a: Int) {
        val s = State
        val hits = ArrayList<PointF>()

        run { // الجانب الأيسر
            val mx = 2 * s.tl.x - p.x
            val d = mx - t.x
            if (d != 0f) {
                val k = (s.tl.x - t.x) / d
                val wy = t.y + k * (p.y - t.y)
                if (k in 0f..1f && wy in s.tl.y..s.br.y) hits.add(PointF(s.tl.x, wy))
            }
        }
        run { // الجانب الأيمن
            val mx = 2 * s.br.x - p.x
            val d = mx - t.x
            if (d != 0f) {
                val k = (s.br.x - t.x) / d
                val wy = t.y + k * (p.y - t.y)
                if (k in 0f..1f && wy in s.tl.y..s.br.y) hits.add(PointF(s.br.x, wy))
            }
        }
        run { // الجانب العلوي
            val my = 2 * s.tl.y - p.y
            val d = my - t.y
            if (d != 0f) {
                val k = (s.tl.y - t.y) / d
                val wx = t.x + k * (p.x - t.x)
                if (k in 0f..1f && wx in s.tl.x..s.br.x) hits.add(PointF(wx, s.tl.y))
            }
        }
        run { // الجانب السفلي
            val my = 2 * s.br.y - p.y
            val d = my - t.y
            if (d != 0f) {
                val k = (s.br.y - t.y) / d
                val wx = t.x + k * (p.x - t.x)
                if (k in 0f..1f && wx in s.tl.x..s.br.x) hits.add(PointF(wx, s.br.y))
            }
        }
        thin.color = col(a, 0, 220, 255)
        for (w in hits) {
            c.drawLine(t.x, t.y, w.x, w.y, thin)
            c.drawLine(w.x, w.y, p.x, p.y, thin)
        }
    }

    override fun onDraw(c: Canvas) {
        // إحداثيات الشاشة الفعلية (يعالج إزاحة النوتش)
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())

        val s = State
        c.drawRect(s.tl.x, s.tl.y, s.br.x, s.br.y, box)

        val r = 0.0153f * (s.br.x - s.tl.x)   // نصف قطر الكرة تقريباً
        val t = s.tgt
        val ps = pockets(r)

        // الجيب المختار = الأقرب إلى المقبض A
        var sel = 0
        var best = Float.MAX_VALUE
        ps.forEachIndexed { i, p ->
            val d = hypot(p.x - s.aim.x, p.y - s.aim.y)
            if (d < best) { best = d; sel = i }
        }

        // بقية الجيوب: خطوط خافتة من نقطة الوسط
        if (s.showPockets) {
            dash.color = col(s.alpha / 2, 255, 220, 0)
            ps.forEachIndexed { i, p ->
                if (i != sel) c.drawLine(t.x, t.y, p.x, p.y, dash)
            }
        }

        val p = ps[sel]
        val dx = p.x - t.x
        val dy = p.y - t.y
        val dist = hypot(dx, dy)
        if (dist > 1f) {
            val ux = dx / dist
            val uy = dy / dist
            val gx = t.x - ux * 2 * r     // موضع البيضاء عند التماس
            val gy = t.y - uy * 2 * r

            if (s.bankMode == 2) {
                ps.forEachIndexed { i, q -> if (i != sel) banks(c, t, q, s.alpha / 2) }
            }
            if (s.bankMode >= 1) banks(c, t, p, s.alpha)

            // الهدف ← الجيب
            solid.color = col(s.alpha, 255, 220, 0)
            c.drawLine(t.x, t.y, p.x, p.y, solid)
            // البيضاء ← موضع التماس
            solid.color = col(s.alpha, 255, 255, 255)
            c.drawLine(s.cue.x, s.cue.y, gx, gy, solid)
            // موضع التماس ← الهدف
            dash.color = col(s.alpha * 2 / 3, 255, 255, 255)
            c.drawLine(gx, gy, t.x, t.y, dash)
            circle.color = col(s.alpha, 255, 255, 255)
            c.drawCircle(gx, gy, r, circle)

            // نهاية خط الهدف عند الجيب
            dot.color = col(s.alpha, 255, 255, 255)
            c.drawCircle(p.x, p.y, 9f, dot)

            // مسار الكرة البيضاء بعد التماس (قاعدة الزاوية القائمة، بدون سبن)
            val cx = gx - s.cue.x
            val cy = gy - s.cue.y
            val cl = hypot(cx, cy)
            if (cl > 1f) {
                val vx = cx / cl
                val vy = cy / cl
                val along = vx * ux + vy * uy
                var qx = vx - along * ux
                var qy = vy - along * uy
                val ql = hypot(qx, qy)
                if (ql > 0.05f) {
                    qx /= ql
                    qy /= ql
                    val tx = if (qx > 0) (s.br.x - gx) / qx else if (qx < 0) (s.tl.x - gx) / qx else Float.MAX_VALUE
                    val ty = if (qy > 0) (s.br.y - gy) / qy else if (qy < 0) (s.tl.y - gy) / qy else Float.MAX_VALUE
                    val len = minOf(minOf(tx, ty), 0.4f * (s.br.x - s.tl.x))
                    if (len > 0f) {
                        solid.color = col(s.alpha, 120, 255, 160)
                        c.drawLine(gx, gy, gx + qx * len, gy + qy * len, solid)
                        circle.color = col(s.alpha, 120, 255, 160)
                        c.drawCircle(gx + qx * len, gy + qy * len, r, circle)
                    }
                }
            }
        }

        // نقطة الوسط
        dot.color = col(s.alpha, 255, 140, 0)
        c.drawCircle(t.x, t.y, 7f, dot)
    }
}
