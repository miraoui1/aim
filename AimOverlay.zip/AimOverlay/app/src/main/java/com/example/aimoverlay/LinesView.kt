package com.example.aimoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PointF
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

object State {
    var cue = PointF(400f, 1300f)   // الكرة البيضاء
    var aim = PointF(700f, 600f)    // نقطة التصويب
    var tl = PointF(120f, 250f)     // أعلى اليسار للطاولة
    var br = PointF(960f, 1900f)    // أسفل اليمين للطاولة
    var bounces = 2
    var alpha = 170
}

class LinesView(ctx: Context) : View(ctx) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }
    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 2f
        style = Paint.Style.STROKE
        color = Color.argb(90, 255, 255, 0)
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }

    private fun trace(): List<PointF> = with(State) {
        val pts = mutableListOf(PointF(cue.x, cue.y))
        var dx = aim.x - cue.x
        var dy = aim.y - cue.y
        val len = hypot(dx, dy)
        if (len < 1f) return pts
        dx /= len
        dy /= len
        var x = cue.x
        var y = cue.y
        repeat(bounces + 1) {
            val tx = if (dx > 0) (br.x - x) / dx else if (dx < 0) (tl.x - x) / dx else Float.MAX_VALUE
            val ty = if (dy > 0) (br.y - y) / dy else if (dy < 0) (tl.y - y) / dy else Float.MAX_VALUE
            val t = min(tx, ty)
            if (t <= 0f) return pts
            x += dx * t
            y += dy * t
            pts.add(PointF(x, y))
            if (tx < ty) dx = -dx else dy = -dy
        }
        pts
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(State.tl.x, State.tl.y, State.br.x, State.br.y, box)
        val pts = trace()
        for (i in 0 until pts.size - 1) {
            val a = if (i == 0) State.alpha else State.alpha * 2 / 3
            line.color = Color.argb(a, 255, 255, 255)
            c.drawLine(pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, line)
        }
    }
}
